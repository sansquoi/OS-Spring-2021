unsigned long xorshf96(void);
long random_limit(long);

